/**
 * 
 */
package dailymixes;

/**
 * @author nakyahv
 * @version 04.09
 *
 */
@SuppressWarnings("serial")
public class DailyMixDataException extends Exception {
    public DailyMixDataException(String string) {
        super(string);

    }
}
